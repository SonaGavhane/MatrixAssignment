﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_array
{

    public class Program
    {
        public static int row, col;
        public static int[] arr = new int[25];

        static void display(int[] a)
        {
            int n = 0;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (n < 25)
                    {
                        Console.Write(a[n]);
                        n++;
                    }
                }
                Console.WriteLine();
            }
        }

        static void display(int[] a, int n1)
        {
            int n = 0;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (n == n1 - 1)
                    {
                        a[n] = 1;
                        row = i;
                        col = j;
                        Console.Write(a[n]);
                        arr[n] = a[n];
                        n++;
                    }
                    else
                    {
                        Console.Write(a[n]);
                        arr[n] = a[n];
                        n++;
                    }

                }
                Console.WriteLine();
            }
        }

        public static int ChangeandGetNewIndex(int r, int c, int[] a, int index)
        {
            int n = 0;
            if (index == 2)
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (i == r + 1)
                        {
                            if (j == c)
                            {
                                a[n] = 1;
                                row = i;
                                col = j;
                            }
                            else
                            {
                                a[n] = 0;
                            }
                            arr[n] = a[n];
                            n++;
                        }
                        else
                        {
                            a[n] = 0;
                            arr[n] = a[n];
                            n++;
                        }

                    }
                }
            }
            else if (index == 8)
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (i == r - 1)
                        {
                            if (j == c)
                            {
                                a[n] = 1;
                                row = i;
                                col = j;
                            }
                            else
                            {
                                a[n] = 0;
                            }
                            arr[n] = a[n];
                            n++;
                        }
                        else
                        {
                            a[n] = 0;
                            arr[n] = a[n];
                            n++;
                        }

                    }
                }
            }
            else if (index == 4)
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (i == r)
                        {
                            if (j == c - 1)
                            {
                                a[n] = 1;
                                row = i;
                                col = j;
                            }
                            else
                            {
                                a[n] = 0;
                            }
                            arr[n] = a[n];
                            n++;
                        }
                        else
                        {
                            a[n] = 0;
                            arr[n] = a[n];
                            n++;
                        }

                    }
                }
            }
            if (index == 6)
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (i == r)
                        {
                            if (j == c + 1)
                            {
                                a[n] = 1;
                                row = i;
                                col = j;
                            }
                            else
                            {
                                a[n] = 0;
                            }
                            arr[n] = a[n];
                            n++;
                        }
                        else
                        {
                            a[n] = 0;
                            arr[n] = a[n];
                            n++;
                        }

                    }
                }
            }
           
            return index;
        }
        public static bool IsValid(int r, int c, int n)
        {
            bool flag = false;
            if (n == 8)
            {
                if (r == 0)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                }
            }
            else if (n == 2)
            {
                if (r == 4)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                }
            }
            else if (n == 4)
            {
                if (c % 5 == 0)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                }
            }
            else if (n == 6)
            {
                if (c % 5 == 4)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                }
            }
            return flag;
        }
       
        static void Main(string[] args)
        { 
            int[] a = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            Console.WriteLine("enter first direction:");
            int input1 = Convert.ToInt32(Console.ReadLine());
            display(a, input1);
            int index = 0;/*' Findoneindex(a);*/
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1:exit 8: Top 2:Down 4:Left 6:Right");
                Console.WriteLine("enter direction:");
                int input = Convert.ToInt32(Console.ReadLine());
                switch (input)
                {
                    case 1:flag = false;
                           break;
                    case 8:  //top
                            if (IsValid(row, col, input))
                            index = ChangeandGetNewIndex(row, col, arr, input);
                            break;
                    case 2:  //down
                            if (IsValid(row, col, input))
                            index = ChangeandGetNewIndex(row, col, arr, input);
                            break;
                    case 4:  //left
                            if (IsValid(row, col, input))
                            index = ChangeandGetNewIndex(row, col, arr, input);
                            break;
                    case 6:  //right
                            if (IsValid(row, col, input))
                            index = ChangeandGetNewIndex(row, col, arr, input);
                            break;
                   default:break;
                }
               display(arr);
            }
            
        }
    }
}
